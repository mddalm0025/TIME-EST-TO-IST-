import React from 'react';
import TimeZoneConverter from './components/TimeZoneConverter';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-purple-600/10"></div>
      <div className="relative z-10">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <TimeZoneConverter />
        </main>
        <Footer />
      </div>
    </div>
  );
}

export default App;