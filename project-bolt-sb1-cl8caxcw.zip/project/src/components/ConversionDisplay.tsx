import React from 'react';
import { Clock } from 'lucide-react';

interface ConversionDisplayProps {
  label: string;
  convertedTime: string;
  timeZone: string;
}

const ConversionDisplay: React.FC<ConversionDisplayProps> = ({
  label,
  convertedTime,
  timeZone
}) => {
  return (
    <div className="w-full">
      <label className="block text-white font-semibold mb-3 text-center">
        <Clock className="inline h-5 w-5 mr-2" />
        {label}
      </label>
      
      <div className="bg-gradient-to-r from-purple-500/20 to-blue-500/20 backdrop-blur-md border border-purple-400/30 rounded-lg px-4 py-3 text-center">
        <div className="text-xl font-mono font-bold text-white mb-1">
          {convertedTime}
        </div>
        <div className="w-full h-1 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"></div>
      </div>
      
      <div className="text-center mt-2">
        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-purple-500/20 text-purple-200 border border-purple-400/30">
          {timeZone}
        </span>
      </div>
    </div>
  );
};

export default ConversionDisplay;