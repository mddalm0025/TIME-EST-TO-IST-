import React from 'react';
import { Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white/5 backdrop-blur-md border-t border-white/10 mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center text-blue-200">
          <p className="flex items-center justify-center space-x-2">
            <span>Made with</span>
            <Heart className="h-4 w-4 text-red-400 fill-current" />
            <span>for global time coordination</span>
          </p>
          <p className="mt-2 text-sm opacity-75">
            © 2025 TimeZone Pro. Beautiful time zone conversion made simple.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;