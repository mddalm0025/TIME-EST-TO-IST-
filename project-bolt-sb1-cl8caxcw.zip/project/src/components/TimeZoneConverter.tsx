import React, { useState, useEffect } from 'react';
import TimeZoneCard from './TimeZoneCard';
import TimeSelector from './TimeSelector';
import ConversionDisplay from './ConversionDisplay';
import { ArrowRightLeft } from 'lucide-react';

const TimeZoneConverter: React.FC = () => {
  const [selectedTime, setSelectedTime] = useState('12:00');
  const [currentESTTime, setCurrentESTTime] = useState('');
  const [currentISTTime, setCurrentISTTime] = useState('');

  useEffect(() => {
    const updateCurrentTimes = () => {
      const now = new Date();
      
      // EST (Eastern Standard Time) - UTC-5
      const estTime = new Date(now.getTime() - (5 * 60 * 60 * 1000));
      const estString = estTime.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
        timeZone: 'America/New_York'
      });
      
      // IST (India Standard Time) - UTC+5:30
      const istString = now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
        timeZone: 'Asia/Kolkata'
      });
      
      setCurrentESTTime(estString);
      setCurrentISTTime(istString);
    };

    updateCurrentTimes();
    const interval = setInterval(updateCurrentTimes, 1000);

    return () => clearInterval(interval);
  }, []);

  const convertTime = (timeStr: string) => {
    const [time, period] = timeStr.split(' ');
    const [hours, minutes] = time.split(':').map(Number);
    
    let hours24 = hours;
    if (period === 'PM' && hours !== 12) hours24 += 12;
    if (period === 'AM' && hours === 12) hours24 = 0;
    
    // EST to IST: Add 10.5 hours (9.5 hours difference + 1 hour for EST vs EDT consideration)
    let istHours = hours24 + 10.5;
    let istMinutes = minutes + 30;
    
    if (istMinutes >= 60) {
      istMinutes -= 60;
      istHours += 1;
    }
    
    const istDate = new Date();
    istDate.setUTCHours(Math.floor(istHours));
    istDate.setUTCMinutes(istMinutes);
    
    if (istHours >= 24) {
      istHours -= 24;
    }
    
    const istHours12 = istHours === 0 ? 12 : istHours > 12 ? istHours - 12 : istHours;
    const istPeriod = istHours >= 12 ? 'PM' : 'AM';
    
    return `${Math.floor(istHours12)}:${String(Math.floor(istMinutes)).padStart(2, '0')} ${istPeriod}`;
  };

  return (
    <div className="max-w-6xl mx-auto">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
          EST to IST Converter
        </h2>
        <p className="text-xl text-blue-200 mb-8">
          Beautiful, instant time zone conversion between Eastern and India Standard Time
        </p>
        
        {/* Current Time Display */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <TimeZoneCard
            timeZone="EST"
            fullName="Eastern Standard Time"
            currentTime={currentESTTime}
            offset="UTC-5"
            flag="🇺🇸"
          />
          <TimeZoneCard
            timeZone="IST"
            fullName="India Standard Time"
            currentTime={currentISTTime}
            offset="UTC+5:30"
            flag="🇮🇳"
          />
        </div>
      </div>

      {/* Time Conversion Section */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-8 mb-8">
        <h3 className="text-2xl font-bold text-white text-center mb-8">
          Convert Any Time
        </h3>
        
        <div className="flex flex-col lg:flex-row items-center justify-center space-y-6 lg:space-y-0 lg:space-x-8">
          <div className="flex-1 max-w-xs">
            <TimeSelector
              label="EST Time"
              value={selectedTime}
              onChange={setSelectedTime}
              timeZone="EST"
            />
          </div>
          
          <div className="flex-shrink-0">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-full">
              <ArrowRightLeft className="h-6 w-6 text-white" />
            </div>
          </div>
          
          <div className="flex-1 max-w-xs">
            <ConversionDisplay
              label="IST Time"
              convertedTime={convertTime(selectedTime)}
              timeZone="IST"
            />
          </div>
        </div>
      </div>

      {/* Information Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6">
          <h4 className="text-lg font-semibold text-white mb-3">Time Difference</h4>
          <p className="text-blue-200">
            IST is <span className="text-yellow-400 font-bold">9.5 hours ahead</span> of EST
          </p>
        </div>
        
        <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6">
          <h4 className="text-lg font-semibold text-white mb-3">Best Meeting Times</h4>
          <p className="text-blue-200">
            <span className="text-green-400 font-bold">9:00 AM - 11:00 AM EST</span><br />
            corresponds to 6:30 PM - 8:30 PM IST
          </p>
        </div>
        
        <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6">
          <h4 className="text-lg font-semibold text-white mb-3">DST Note</h4>
          <p className="text-blue-200">
            Remember that EST observes <span className="text-orange-400 font-bold">Daylight Saving Time</span>, 
            while IST remains constant year-round.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TimeZoneConverter;