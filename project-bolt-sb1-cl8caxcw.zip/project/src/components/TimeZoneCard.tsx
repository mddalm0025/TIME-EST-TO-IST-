import React from 'react';
import { MapPin } from 'lucide-react';

interface TimeZoneCardProps {
  timeZone: string;
  fullName: string;
  currentTime: string;
  offset: string;
  flag: string;
}

const TimeZoneCard: React.FC<TimeZoneCardProps> = ({
  timeZone,
  fullName,
  currentTime,
  offset,
  flag
}) => {
  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-6 hover:bg-white/15 transition-all duration-300 transform hover:scale-105">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <span className="text-2xl">{flag}</span>
          <div>
            <h3 className="text-xl font-bold text-white">{timeZone}</h3>
            <p className="text-blue-200 text-sm">{fullName}</p>
          </div>
        </div>
        <div className="flex items-center space-x-1 text-blue-300">
          <MapPin className="h-4 w-4" />
          <span className="text-sm">{offset}</span>
        </div>
      </div>
      
      <div className="text-center">
        <div className="text-3xl md:text-4xl font-mono font-bold text-white mb-2">
          {currentTime || '--:-- --'}
        </div>
        <div className="w-full h-1 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full opacity-60"></div>
      </div>
    </div>
  );
};

export default TimeZoneCard;