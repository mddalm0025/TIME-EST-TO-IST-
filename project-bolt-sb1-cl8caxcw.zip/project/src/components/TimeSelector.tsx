import React from 'react';
import { Clock } from 'lucide-react';

interface TimeSelectorProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  timeZone: string;
}

const TimeSelector: React.FC<TimeSelectorProps> = ({
  label,
  value,
  onChange,
  timeZone
}) => {
  const generateTimeOptions = () => {
    const options = [];
    for (let hour = 1; hour <= 12; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const minuteStr = minute.toString().padStart(2, '0');
        options.push(`${hour}:${minuteStr} AM`);
        options.push(`${hour}:${minuteStr} PM`);
      }
    }
    return options.sort();
  };

  return (
    <div className="w-full">
      <label className="block text-white font-semibold mb-3 text-center">
        <Clock className="inline h-5 w-5 mr-2" />
        {label}
      </label>
      
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-white/10 backdrop-blur-md border border-white/20 rounded-lg px-4 py-3 text-white font-mono text-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent appearance-none cursor-pointer hover:bg-white/15 transition-all duration-200"
        >
          {generateTimeOptions().map((time) => (
            <option key={time} value={time} className="bg-slate-800 text-white">
              {time}
            </option>
          ))}
        </select>
        
        <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
          <svg className="h-5 w-5 text-white/60" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </div>
      </div>
      
      <div className="text-center mt-2">
        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blue-500/20 text-blue-200 border border-blue-400/30">
          {timeZone}
        </span>
      </div>
    </div>
  );
};

export default TimeSelector;